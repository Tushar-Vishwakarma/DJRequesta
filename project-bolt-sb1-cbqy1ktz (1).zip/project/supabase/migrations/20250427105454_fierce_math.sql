/*
  # Create songs table and storage

  1. New Tables
    - `songs`
      - `id` (uuid, primary key)
      - `title` (text, required)
      - `artist` (text, required)
      - `album` (text)
      - `cover_image` (text)
      - `duration` (integer, in seconds)
      - `genre` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `venue_id` (uuid, foreign key)
      - `uploaded_by` (uuid, foreign key)

  2. Security
    - Enable RLS on `songs` table
    - Add policies for:
      - Public read access
      - DJ/Admin write access
*/

-- Create songs table
CREATE TABLE IF NOT EXISTS songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  artist text NOT NULL,
  album text,
  cover_image text,
  duration integer,
  genre text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  venue_id uuid REFERENCES auth.users(id),
  uploaded_by uuid REFERENCES auth.users(id),
  CONSTRAINT title_artist_unique UNIQUE (title, artist)
);

-- Enable RLS
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access"
  ON songs
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow DJ/Admin write access"
  ON songs
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.uid() = id
      AND (raw_user_meta_data->>'role' IN ('dj', 'admin'))
    )
  );

-- Create storage bucket for song covers
INSERT INTO storage.buckets (id, name, public) 
VALUES ('song_covers', 'song_covers', true);

-- Allow public access to song covers
CREATE POLICY "Public Access"
  ON storage.objects FOR SELECT
  TO public
  USING ( bucket_id = 'song_covers' );

-- Allow authenticated users to upload covers
CREATE POLICY "Authenticated users can upload song covers"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK ( bucket_id = 'song_covers' );