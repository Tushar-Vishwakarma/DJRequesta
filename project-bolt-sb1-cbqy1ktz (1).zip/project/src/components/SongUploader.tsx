import React, { useState } from 'react';
import { Upload, Download, FileSpreadsheet } from 'lucide-react';
import * as XLSX from 'xlsx';
import Button from './ui/Button';
import { useAppContext } from '../contexts/AppContext';

interface SongUploadData {
  title: string;
  artist: string;
  album?: string;
  duration?: number;
  genre?: string;
}

interface SongUploaderProps {
  variant?: 'full' | 'compact';
}

const SongUploader: React.FC<SongUploaderProps> = ({ variant = 'full' }) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const { supabase, currentUser, isAuthenticated } = useAppContext();

  if (!isAuthenticated || !['dj', 'admin'].includes(currentUser?.role || '')) {
    return null;
  }

  const downloadTemplate = () => {
    const template = [
      {
        title: 'Example Song',
        artist: 'Example Artist',
        album: 'Example Album',
        duration: 180,
        genre: 'Pop'
      }
    ];

    const ws = XLSX.utils.json_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Songs Template');
    XLSX.writeFile(wb, 'songs_upload_template.xlsx');
  };

  const validateSongData = (data: any): data is SongUploadData => {
    return (
      typeof data.title === 'string' &&
      typeof data.artist === 'string' &&
      data.title.length > 0 &&
      data.artist.length > 0
    );
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setUploadError(null);

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      const validSongs: SongUploadData[] = [];
      const errors: string[] = [];

      jsonData.forEach((row: any, index: number) => {
        if (validateSongData(row)) {
          validSongs.push(row);
        } else {
          errors.push(`Row ${index + 2}: Invalid song data`);
        }
      });

      if (errors.length > 0) {
        setUploadError(`Validation errors:\n${errors.join('\n')}`);
        return;
      }

      // Upload songs to Supabase
      const { error } = await supabase
        .from('songs')
        .insert(
          validSongs.map(song => ({
            ...song,
            uploaded_by: currentUser?.id,
            venue_id: currentUser?.venue_id
          }))
        );

      if (error) throw error;

      alert(`Successfully uploaded ${validSongs.length} songs!`);
      event.target.value = '';
    } catch (error) {
      console.error('Upload error:', error);
      setUploadError('Failed to upload songs. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  if (variant === 'compact') {
    return (
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={downloadTemplate}
          icon={<Download className="w-4 h-4" />}
        >
          Template
        </Button>

        <div className="relative">
          <Button
            variant="secondary"
            size="sm"
            icon={<FileSpreadsheet className="w-4 h-4" />}
          >
            Upload Songs
          </Button>
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileUpload}
            className="absolute inset-0 opacity-0 cursor-pointer"
            disabled={isUploading}
          />
        </div>

        {isUploading && (
          <Upload className="animate-bounce w-5 h-5 text-blue-400" />
        )}
      </div>
    );
  }

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
      <h2 className="text-xl font-semibold text-white mb-4">Upload Songs</h2>
      
      <div className="space-y-4">
        <div>
          <Button
            variant="outline"
            onClick={downloadTemplate}
            icon={<Download className="w-4 h-4" />}
          >
            Download Template
          </Button>
          <p className="mt-2 text-sm text-gray-400">
            Download the Excel template and fill it with your songs.
          </p>
        </div>

        <div className="border-t border-gray-800 pt-4">
          <label className="block">
            <div className="mb-2">
              <Button
                variant="secondary"
                icon={<FileSpreadsheet className="w-4 h-4" />}
              >
                Select Excel File
              </Button>
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileUpload}
                className="hidden"
                disabled={isUploading}
              />
            </div>
            <p className="text-sm text-gray-400">
              Upload your filled Excel template to add songs.
            </p>
          </label>
        </div>

        {isUploading && (
          <div className="text-blue-400">
            <Upload className="animate-bounce w-5 h-5 inline mr-2" />
            Uploading songs...
          </div>
        )}

        {uploadError && (
          <div className="text-red-400 text-sm whitespace-pre-line">
            {uploadError}
          </div>
        )}
      </div>
    </div>
  );
};

export default SongUploader;