import React, { useState } from 'react';
import { Scan } from 'lucide-react';
import Button from './ui/Button';

interface QRScannerProps {
  onScan: (data: string) => void;
}

const QRScanner: React.FC<QRScannerProps> = ({ onScan }) => {
  const [scanning, setScanning] = useState(false);
  
  const handleStartScan = () => {
    setScanning(true);
    
    // Simulate QR code scan for prototype
    setTimeout(() => {
      setScanning(false);
      onScan('venue_123'); // Simulate successful scan
    }, 2000);
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg p-6 text-center">
      {scanning ? (
        <div className="mb-4 relative">
          <div className="border-2 border-dashed border-purple-500 rounded-lg h-48 flex items-center justify-center">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-full h-full max-w-[200px] max-h-[200px] relative">
                <div className="absolute inset-0 border-2 border-fuchsia-500">
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-fuchsia-500"></div>
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-fuchsia-500"></div>
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-fuchsia-500"></div>
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-fuchsia-500"></div>
                </div>
                <div 
                  className="h-1 bg-fuchsia-500 absolute w-full left-0"
                  style={{
                    animation: 'scan 2s linear infinite',
                    top: '0%'
                  }}
                ></div>
              </div>
            </div>
            <p className="text-gray-400 relative z-10">Scanning...</p>
          </div>
        </div>
      ) : (
        <div className="mb-4">
          <div className="h-48 border-2 border-dashed border-gray-700 rounded-lg flex items-center justify-center">
            <div className="text-center px-4">
              <Scan className="w-12 h-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400">
                Scan the venue's QR code to request a song.
              </p>
            </div>
          </div>
        </div>
      )}
      
      <Button
        onClick={handleStartScan}
        disabled={scanning}
        fullWidth
      >
        {scanning ? 'Scanning...' : 'Scan QR Code'}
      </Button>
      
      <style jsx>{`
        @keyframes scan {
          0% { top: 0%; }
          50% { top: 100%; }
          100% { top: 0%; }
        }
      `}</style>
    </div>
  );
};

export default QRScanner;