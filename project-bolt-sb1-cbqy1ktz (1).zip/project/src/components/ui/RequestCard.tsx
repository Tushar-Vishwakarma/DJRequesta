import React, { useState } from 'react';
import { Request } from '../../types';
import { Song } from '../../types';
import Button from './Button';
import { useAppContext } from '../../contexts/AppContext';

interface RequestCardProps {
  request: Request;
  song: Song;
  isDj?: boolean;
  variant?: 'grid' | 'list';
}

const RequestCard: React.FC<RequestCardProps> = ({ 
  request, 
  song, 
  isDj = false,
  variant = 'grid'
}) => {
  const { updateRequestStatus } = useAppContext();
  const [rejectionReason, setRejectionReason] = useState('');
  const [showRejectionForm, setShowRejectionForm] = useState(false);

  const getStatusBadge = () => {
    const baseClasses = 'px-2 py-1 rounded-full text-xs font-semibold';
    
    switch (request.status) {
      case 'pending':
        return <span className={`${baseClasses} bg-yellow-500 text-yellow-900`}>Pending</span>;
      case 'accepted':
        return <span className={`${baseClasses} bg-green-500 text-green-900`}>Accepted</span>;
      case 'rejected':
        return <span className={`${baseClasses} bg-red-500 text-red-900`}>Rejected</span>;
      case 'played':
        return <span className={`${baseClasses} bg-blue-500 text-blue-900`}>Played</span>;
      default:
        return null;
    }
  };

  const getCategoryBadge = () => {
    const baseClasses = 'px-2 py-1 rounded-full text-xs font-semibold';
    
    switch (request.category) {
      case 'platinum':
        return <span className={`${baseClasses} bg-purple-500 text-white`}>Platinum</span>;
      case 'gold':
        return <span className={`${baseClasses} bg-yellow-500 text-yellow-900`}>Gold</span>;
      case 'silver':
        return <span className={`${baseClasses} bg-gray-500 text-white`}>Silver</span>;
      default:
        return null;
    }
  };

  const formatTime = (timeString: string) => {
    const date = new Date(timeString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleAccept = () => {
    updateRequestStatus(request.id, 'accepted');
  };

  const handleReject = () => {
    if (!rejectionReason.trim()) {
      setShowRejectionForm(true);
      return;
    }
    
    updateRequestStatus(request.id, 'rejected', rejectionReason);
    setShowRejectionForm(false);
    setRejectionReason('');
  };

  const handlePlayed = () => {
    updateRequestStatus(request.id, 'played');
  };

  if (variant === 'list') {
    return (
      <div className={`
        bg-gray-900 border border-gray-800 rounded-lg overflow-hidden
        transition-all duration-300 hover:border-gray-700
      `}>
        <div className="p-4 flex items-center">
          <img 
            src={song.coverImage} 
            alt={song.title} 
            className="w-16 h-16 rounded-md object-cover" 
          />
          
          <div className="ml-4 flex-1">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-white">{song.title}</h3>
                <p className="text-sm text-gray-400">{song.artist}</p>
              </div>
              
              <div className="text-right">
                <div className="flex gap-2">
                  {getStatusBadge()}
                  {getCategoryBadge()}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {formatTime(request.requestTime)}
                </p>
              </div>
            </div>
            
            <div className="mt-2">
              <span className="text-sm text-gray-400 mr-3">
                From: {request.requesterName}
              </span>
              
              {request.dedication && (
                <span className="text-sm italic text-gray-400">
                  "{request.dedication}"
                </span>
              )}
            </div>
            
            {isDj && request.status === 'pending' && (
              <div className="mt-3 flex gap-2">
                <Button 
                  variant="success" 
                  size="sm" 
                  onClick={handleAccept}
                >
                  Accept
                </Button>
                
                {showRejectionForm ? (
                  <div className="flex-1 flex gap-2">
                    <input
                      type="text"
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      placeholder="Reason for rejection..."
                      className="flex-1 bg-gray-800 border border-gray-700 rounded px-3 py-1 text-white text-sm"
                    />
                    <Button 
                      variant="danger" 
                      size="sm" 
                      onClick={handleReject}
                      disabled={!rejectionReason.trim()}
                    >
                      Confirm
                    </Button>
                  </div>
                ) : (
                  <Button 
                    variant="danger" 
                    size="sm" 
                    onClick={() => setShowRejectionForm(true)}
                  >
                    Reject
                  </Button>
                )}
              </div>
            )}
            
            {isDj && request.status === 'accepted' && (
              <div className="mt-3">
                <Button 
                  variant="primary" 
                  size="sm" 
                  onClick={handlePlayed}
                >
                  Mark as Played
                </Button>
              </div>
            )}
            
            {request.status === 'rejected' && request.rejectionReason && (
              <div className="mt-2 text-sm text-red-400">
                Rejected: {request.rejectionReason}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`
      border border-gray-800 rounded-lg overflow-hidden
      ${request.category === 'platinum' ? 'bg-gradient-to-r from-purple-900/50 to-pink-900/50' : 'bg-gray-900'}
      transition-all duration-300 hover:border-gray-700
    `}>
      <div className="p-4">
        <div className="flex items-start">
          <div className="flex-shrink-0 mr-4">
            <img 
              src={song.coverImage} 
              alt={song.title} 
              className="w-16 h-16 rounded-md object-cover" 
            />
          </div>
          
          <div className="flex-1">
            <div className="flex justify-between">
              <div>
                <h3 className="font-bold text-white">{song.title}</h3>
                <p className="text-sm text-gray-400">{song.artist}</p>
              </div>
              <div className="text-right">
                <div className="flex gap-2">
                  {getStatusBadge()}
                  {getCategoryBadge()}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {formatTime(request.requestTime)}
                </p>
              </div>
            </div>
            
            <div className="mt-2">
              <span className="text-sm text-gray-400 mr-3">
                From: {request.requesterName}
              </span>
              
              {request.dedication && (
                <div className="mt-1">
                  <p className="text-xs italic text-gray-400">
                    "{request.dedication}"
                  </p>
                </div>
              )}
            </div>
            
            {isDj && request.status === 'pending' && (
              <div className="mt-3 space-y-2">
                <div className="flex gap-2">
                  <Button 
                    variant="success" 
                    size="sm" 
                    onClick={handleAccept}
                  >
                    Accept
                  </Button>
                  
                  <Button 
                    variant="danger" 
                    size="sm" 
                    onClick={() => setShowRejectionForm(true)}
                  >
                    Reject
                  </Button>
                </div>
                
                {showRejectionForm && (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      placeholder="Reason for rejection..."
                      className="flex-1 bg-gray-800 border border-gray-700 rounded px-3 py-1 text-white text-sm"
                    />
                    <Button 
                      variant="danger" 
                      size="sm" 
                      onClick={handleReject}
                      disabled={!rejectionReason.trim()}
                    >
                      Confirm
                    </Button>
                  </div>
                )}
              </div>
            )}
            
            {isDj && request.status === 'accepted' && (
              <div className="mt-3">
                <Button 
                  variant="primary" 
                  size="sm" 
                  onClick={handlePlayed}
                >
                  Mark as Played
                </Button>
              </div>
            )}
            
            {request.status === 'rejected' && request.rejectionReason && (
              <div className="mt-2 text-sm text-red-400">
                Rejected: {request.rejectionReason}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestCard;