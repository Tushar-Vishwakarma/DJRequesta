export type User = {
  id: string;
  name: string;
  email: string;
  role: 'guest' | 'dj' | 'admin';
  profileImage?: string;
};

export type Venue = {
  id: string;
  name: string;
  logo?: string;
  theme?: {
    primary: string;
    secondary: string;
    accent: string;
  };
  address: string;
  description: string;
};

export type PricingCategory = 'gold' | 'silver' | 'platinum';

export type CategoryPricing = {
  category: PricingCategory;
  price: number;
  maxSlotsPerHour: number;
};

export type Song = {
  id: string;
  title: string;
  artist: string;
  album?: string;
  coverImage: string;
  duration: number; // in seconds
  genre?: string;
};

export type RequestStatus = 'pending' | 'accepted' | 'rejected' | 'played';

export type Request = {
  id: string;
  songId: string;
  requesterId?: string;
  requesterName: string;
  venueId: string;
  djId?: string;
  status: RequestStatus;
  requestTime: string;
  category: PricingCategory;
  rejectionReason?: string;
  dedication?: string;
  paymentId?: string;
};

export type VenueStats = {
  totalRequests: number;
  totalRevenue: number;
  requestsByCategory: {
    [key in PricingCategory]: {
      count: number;
      revenue: number;
    };
  };
};