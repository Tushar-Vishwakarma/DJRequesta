import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import RequestCard from '../components/ui/RequestCard';
import Button from '../components/ui/Button';
import { useAppContext } from '../contexts/AppContext';

const QueueView: React.FC = () => {
  const { songRequests, allSongs, currentUser } = useAppContext();
  const navigate = useNavigate();
  
  const isDj = currentUser?.role === 'dj';
  
  // Get requests that are pending or accepted, sort by status and time
  const activeRequests = useMemo(() => {
    return songRequests
      .filter(request => ['pending', 'accepted'].includes(request.status))
      .sort((a, b) => {
        // First sort by status (accepted first)
        if (a.status === 'accepted' && b.status !== 'accepted') return -1;
        if (a.status !== 'accepted' && b.status === 'accepted') return 1;
        
        // Then by boosted status
        if (a.boosted && !b.boosted) return -1;
        if (!a.boosted && b.boosted) return 1;
        
        // Finally by request time
        return new Date(b.requestTime).getTime() - new Date(a.requestTime).getTime();
      });
  }, [songRequests]);
  
  // Get song objects for each request
  const requestsWithSongs = useMemo(() => {
    return activeRequests.map(request => {
      const song = allSongs.find(s => s.id === request.songId);
      return { request, song: song! };
    }).filter(({ song }) => song !== undefined);
  }, [activeRequests, allSongs]);
  
  if (requestsWithSongs.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl md:text-3xl font-bold text-white mb-4">
          Request Queue
        </h1>
        <p className="text-gray-400 text-lg mb-8">
          There are no active song requests in the queue right now.
        </p>
        <Button onClick={() => navigate('/songs')}>
          Request a Song
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl md:text-3xl font-bold text-white mb-6">
        {isDj ? 'Manage Requests' : 'Request Queue'}
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {requestsWithSongs.map(({ request, song }) => (
          <RequestCard
            key={request.id}
            request={request}
            song={song}
            isDj={isDj}
          />
        ))}
      </div>
      
      {!isDj && (
        <div className="mt-8 text-center">
          <Button onClick={() => navigate('/songs')}>
            Request Another Song
          </Button>
        </div>
      )}
    </div>
  );
};

export default QueueView;