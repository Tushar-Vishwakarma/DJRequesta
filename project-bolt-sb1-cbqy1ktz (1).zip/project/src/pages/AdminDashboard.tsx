import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, TrendingUp, Clock } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useAppContext } from '../contexts/AppContext';
import { CategoryPricing, PricingCategory } from '../types';

const AdminDashboard: React.FC = () => {
  const { currentUser, songRequests, venues, updateCategoryPricing } = useAppContext();
  const navigate = useNavigate();
  
  const [pricingSettings, setPricingSettings] = useState<CategoryPricing[]>([
    { category: 'platinum', price: 500, maxSlotsPerHour: 2 },
    { category: 'gold', price: 300, maxSlotsPerHour: 3 },
    { category: 'silver', price: 100, maxSlotsPerHour: 5 }
  ]);
  
  // Redirect if not an admin
  if (currentUser?.role !== 'admin') {
    navigate('/login');
    return null;
  }
  
  // Calculate stats
  const stats = useMemo(() => {
    const totalRequests = songRequests.length;
    const totalRevenue = songRequests.reduce((acc, req) => {
      const category = pricingSettings.find(p => p.category === req.category);
      return acc + (category?.price || 0);
    }, 0);
    
    const requestsByCategory = songRequests.reduce((acc, req) => {
      const category = req.category;
      const price = pricingSettings.find(p => p.category === category)?.price || 0;
      
      acc[category] = acc[category] || { count: 0, revenue: 0 };
      acc[category].count++;
      acc[category].revenue += price;
      
      return acc;
    }, {} as Record<PricingCategory, { count: number; revenue: number }>);
    
    return {
      totalRequests,
      totalRevenue,
      requestsByCategory
    };
  }, [songRequests, pricingSettings]);

  const handlePriceChange = (category: PricingCategory, price: number) => {
    const newSettings = pricingSettings.map(setting => 
      setting.category === category ? { ...setting, price } : setting
    );
    setPricingSettings(newSettings);
    updateCategoryPricing(newSettings);
  };

  const handleSlotChange = (category: PricingCategory, slots: number) => {
    const newSettings = pricingSettings.map(setting => 
      setting.category === category ? { ...setting, maxSlotsPerHour: slots } : setting
    );
    setPricingSettings(newSettings);
    updateCategoryPricing(newSettings);
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
            Admin Dashboard
          </h1>
          <p className="text-gray-400">
            Welcome back, {currentUser.name}
          </p>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-400 text-sm">Total Revenue</p>
            <TrendingUp className="text-green-400 w-5 h-5" />
          </div>
          <p className="text-3xl font-bold text-green-400">₹{stats.totalRevenue}</p>
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-400 text-sm">Total Requests</p>
            <Clock className="text-blue-400 w-5 h-5" />
          </div>
          <p className="text-3xl font-bold text-white">{stats.totalRequests}</p>
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-400 text-sm">Active Venues</p>
            <Settings className="text-purple-400 w-5 h-5" />
          </div>
          <p className="text-3xl font-bold text-white">{venues?.length || 0}</p>
        </div>
      </div>
      
      {/* Pricing Settings */}
      <div className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden mb-8">
        <div className="p-6 border-b border-gray-800">
          <h2 className="text-xl font-semibold text-white">Pricing Settings</h2>
          <p className="text-gray-400 text-sm mt-1">
            Configure pricing and slots for each category
          </p>
        </div>
        
        <div className="p-6">
          <div className="grid gap-6">
            {pricingSettings.map(setting => (
              <div key={setting.category} className="bg-gray-800 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-white capitalize mb-4">
                  {setting.category}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Input
                      label="Price (₹)"
                      type="number"
                      value={setting.price.toString()}
                      onChange={(e) => handlePriceChange(
                        setting.category,
                        parseInt(e.target.value) || 0
                      )}
                    />
                  </div>
                  
                  <div>
                    <Input
                      label="Max Slots per Hour"
                      type="number"
                      value={setting.maxSlotsPerHour.toString()}
                      onChange={(e) => handleSlotChange(
                        setting.category,
                        parseInt(e.target.value) || 0
                      )}
                    />
                  </div>
                </div>
                
                <div className="mt-4">
                  <p className="text-sm text-gray-400">
                    Current Stats:
                    <span className="ml-2">
                      {stats.requestsByCategory[setting.category]?.count || 0} requests,
                      ₹{stats.requestsByCategory[setting.category]?.revenue || 0} revenue
                    </span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          variant="secondary"
          onClick={() => navigate('/admin/venues')}
        >
          Manage Venues
        </Button>
        
        <Button
          variant="secondary"
          onClick={() => navigate('/admin/reports')}
        >
          View Reports
        </Button>
        
        <Button
          variant="secondary"
          onClick={() => navigate('/admin/settings')}
        >
          System Settings
        </Button>
      </div>
    </div>
  );
};

export default AdminDashboard;