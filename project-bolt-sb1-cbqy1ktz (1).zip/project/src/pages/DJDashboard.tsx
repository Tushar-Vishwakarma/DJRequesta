import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { List, Grid, Upload } from 'lucide-react';
import Button from '../components/ui/Button';
import RequestCard from '../components/ui/RequestCard';
import SongUploader from '../components/SongUploader';
import { useAppContext } from '../contexts/AppContext';
import { PricingCategory } from '../types';

const DJDashboard: React.FC = () => {
  const { currentUser, songRequests, allSongs } = useAppContext();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'pending' | 'accepted' | 'completed' | 'songs'>('pending');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedCategory, setSelectedCategory] = useState<PricingCategory | 'all'>('all');
  
  // Redirect if not a DJ
  if (currentUser?.role !== 'dj') {
    navigate('/login');
    return null;
  }
  
  // Filter and sort requests
  const filteredRequests = useMemo(() => {
    let requests = songRequests;
    
    // Filter by status
    switch (activeTab) {
      case 'pending':
        requests = requests.filter(req => req.status === 'pending');
        break;
      case 'accepted':
        requests = requests.filter(req => req.status === 'accepted');
        break;
      case 'completed':
        requests = requests.filter(req => req.status === 'played' || req.status === 'rejected');
        break;
    }
    
    // Filter by category
    if (selectedCategory !== 'all') {
      requests = requests.filter(req => req.category === selectedCategory);
    }
    
    // Sort by category priority (platinum > gold > silver)
    return requests.sort((a, b) => {
      const categoryPriority = { platinum: 3, gold: 2, silver: 1 };
      return categoryPriority[b.category] - categoryPriority[a.category];
    });
  }, [songRequests, activeTab, selectedCategory]);
  
  // Get song objects for each request
  const requestsWithSongs = useMemo(() => {
    return filteredRequests.map(request => {
      const song = allSongs.find(s => s.id === request.songId);
      return { request, song: song! };
    }).filter(({ song }) => song !== undefined);
  }, [filteredRequests, allSongs]);
  
  const renderContent = () => {
    if (activeTab === 'songs') {
      return <SongUploader />;
    }

    if (requestsWithSongs.length === 0) {
      return (
        <div className="text-center py-12 bg-gray-900 rounded-lg">
          <p className="text-gray-400">
            No {activeTab} requests at the moment.
          </p>
        </div>
      );
    }

    return (
      <div className={
        viewMode === 'grid'
          ? 'grid grid-cols-1 md:grid-cols-2 gap-4'
          : 'space-y-4'
      }>
        {requestsWithSongs.map(({ request, song }) => (
          <RequestCard
            key={request.id}
            request={request}
            song={song}
            isDj={true}
            variant={viewMode}
          />
        ))}
      </div>
    );
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
            DJ Dashboard
          </h1>
          <p className="text-gray-400">
            Welcome back, {currentUser.name}
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'grid' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
              icon={<Grid className="w-4 h-4" />}
            >
              Grid
            </Button>
            <Button
              variant={viewMode === 'list' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
              icon={<List className="w-4 h-4" />}
            >
              List
            </Button>
          </div>
          
          <select
            className="bg-gray-800 text-white border border-gray-700 rounded-lg px-3 py-2"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value as PricingCategory | 'all')}
          >
            <option value="all">All Categories</option>
            <option value="platinum">Platinum</option>
            <option value="gold">Gold</option>
            <option value="silver">Silver</option>
          </select>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-800 mb-6">
        <div className="flex overflow-x-auto">
          <button
            className={`py-2 px-4 font-medium text-sm mr-4 border-b-2 ${
              activeTab === 'pending' 
                ? 'border-fuchsia-500 text-white' 
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('pending')}
          >
            Pending Requests
          </button>
          
          <button
            className={`py-2 px-4 font-medium text-sm mr-4 border-b-2 ${
              activeTab === 'accepted' 
                ? 'border-fuchsia-500 text-white' 
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('accepted')}
          >
            Accepted
          </button>
          
          <button
            className={`py-2 px-4 font-medium text-sm mr-4 border-b-2 ${
              activeTab === 'completed' 
                ? 'border-fuchsia-500 text-white' 
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('completed')}
          >
            Completed
          </button>

          <button
            className={`py-2 px-4 font-medium text-sm mr-4 border-b-2 ${
              activeTab === 'songs' 
                ? 'border-fuchsia-500 text-white' 
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('songs')}
          >
            Manage Songs
          </button>
        </div>
      </div>
      
      {/* Content */}
      {renderContent()}
      
      {/* Quick Navigation */}
      <div className="mt-8 flex flex-wrap gap-4">
        <Button
          variant="outline"
          onClick={() => navigate('/queue')}
        >
          View Queue
        </Button>
        
        <Button
          variant="secondary"
          onClick={() => navigate('/songs')}
          icon={<Upload className="w-4 h-4" />}
        >
          Upload Songs
        </Button>
      </div>
    </div>
  );
};

export default DJDashboard;