import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Song, Request, Venue, CategoryPricing } from '../types';
import { songs, requests as mockRequests, users, venues } from '../data/mockData';

interface AppContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  allSongs: Song[];
  filteredSongs: Song[];
  setFilteredSongs: (songs: Song[]) => void;
  songRequests: Request[];
  addRequest: (request: Omit<Request, 'id' | 'requestTime'>) => void;
  updateRequestStatus: (requestId: string, status: Request['status']) => void;
  boostedRequest: (requestId: string) => void;
  currentVenue: Venue | null;
  setCurrentVenue: (venue: Venue | null) => void;
  nowPlaying: Song | null;
  setNowPlaying: (song: Song | null) => void;
  searchSongs: (query: string) => void;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateCategoryPricing: (settings: CategoryPricing[]) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [allSongs] = useState<Song[]>(songs);
  const [filteredSongs, setFilteredSongs] = useState<Song[]>(songs);
  const [songRequests, setSongRequests] = useState<Request[]>(mockRequests);
  const [currentVenue, setCurrentVenue] = useState<Venue | null>(venues[0]);
  const [nowPlaying, setNowPlaying] = useState<Song | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Initialize now playing with a random song
  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * songs.length);
    setNowPlaying(songs[randomIndex]);
  }, []);

  const addRequest = (requestData: Omit<Request, 'id' | 'requestTime'>) => {
    const newRequest: Request = {
      ...requestData,
      id: Date.now().toString(),
      requestTime: new Date().toISOString(),
    };
    
    setSongRequests((prev) => [newRequest, ...prev]);
    return newRequest;
  };

  const updateRequestStatus = (requestId: string, status: Request['status']) => {
    setSongRequests((prev) =>
      prev.map((request) =>
        request.id === requestId ? { ...request, status } : request
      )
    );

    // If status is "played", update now playing
    if (status === 'played') {
      const request = songRequests.find(r => r.id === requestId);
      if (request) {
        const song = allSongs.find(s => s.id === request.songId);
        if (song) {
          setNowPlaying(song);
        }
      }
    }
  };

  const boostedRequest = (requestId: string) => {
    setSongRequests((prev) =>
      prev.map((request) =>
        request.id === requestId ? { ...request, boosted: true, fee: request.fee + 100 } : request
      )
    );
  };

  const searchSongs = (query: string) => {
    if (!query) {
      setFilteredSongs(allSongs);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    const filtered = allSongs.filter(
      (song) =>
        song.title.toLowerCase().includes(lowercaseQuery) ||
        song.artist.toLowerCase().includes(lowercaseQuery) ||
        (song.album && song.album.toLowerCase().includes(lowercaseQuery))
    );
    
    setFilteredSongs(filtered);
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    // For prototype, just find the user with matching email
    const user = users.find(u => u.email === email);
    
    if (user) {
      setCurrentUser(user);
      setIsAuthenticated(true);
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  const updateCategoryPricing = (settings: CategoryPricing[]) => {
    // In a real application, this would make an API call to update the settings
    // For now, we'll just log the update
    console.log('Updating category pricing settings:', settings);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        allSongs,
        filteredSongs,
        setFilteredSongs,
        songRequests,
        addRequest,
        updateRequestStatus,
        boostedRequest,
        currentVenue,
        setCurrentVenue,
        nowPlaying,
        setNowPlaying,
        searchSongs,
        isAuthenticated,
        login,
        logout,
        updateCategoryPricing
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};