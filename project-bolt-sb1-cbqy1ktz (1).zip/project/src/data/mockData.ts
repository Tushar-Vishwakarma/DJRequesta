import { Song, Request, User, Venue } from '../types';

// Mock Songs
export const songs: Song[] = [
  {
    id: '1',
    title: 'Blinding Lights',
    artist: 'The Weeknd',
    album: 'After Hours',
    coverImage: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg',
    duration: 203,
    genre: 'Pop'
  },
  {
    id: '2',
    title: 'Dance Monkey',
    artist: 'Tones and I',
    album: 'The Kids Are Coming',
    coverImage: 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg',
    duration: 210,
    genre: 'Pop'
  },
  {
    id: '3',
    title: 'Don\'t Start Now',
    artist: 'Dua Lipa',
    album: 'Future Nostalgia',
    coverImage: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg',
    duration: 183,
    genre: 'Pop'
  },
  {
    id: '4',
    title: 'Savage Love',
    artist: 'Jason Derulo',
    album: 'Savage Love',
    coverImage: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg',
    duration: 174,
    genre: 'R&B'
  },
  {
    id: '5',
    title: 'Watermelon Sugar',
    artist: 'Harry Styles',
    album: 'Fine Line',
    coverImage: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg',
    duration: 174,
    genre: 'Pop Rock'
  },
  {
    id: '6',
    title: 'Bad Guy',
    artist: 'Billie Eilish',
    album: 'When We All Fall Asleep, Where Do We Go?',
    coverImage: 'https://images.pexels.com/photos/1694900/pexels-photo-1694900.jpeg',
    duration: 194,
    genre: 'Electropop'
  },
  {
    id: '7',
    title: 'Levitating',
    artist: 'Dua Lipa ft. DaBaby',
    album: 'Future Nostalgia',
    coverImage: 'https://images.pexels.com/photos/1683260/pexels-photo-1683260.jpeg',
    duration: 203,
    genre: 'Disco Pop'
  },
  {
    id: '8',
    title: 'Dynamite',
    artist: 'BTS',
    album: 'BE',
    coverImage: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg',
    duration: 199,
    genre: 'Disco Pop'
  },
  {
    id: '9',
    title: 'Mood',
    artist: '24kGoldn ft. Iann Dior',
    album: 'El Dorado',
    coverImage: 'https://images.pexels.com/photos/1644888/pexels-photo-1644888.jpeg',
    duration: 140,
    genre: 'Pop Rap'
  },
  {
    id: '10',
    title: 'Positions',
    artist: 'Ariana Grande',
    album: 'Positions',
    coverImage: 'https://images.pexels.com/photos/1616470/pexels-photo-1616470.jpeg',
    duration: 172,
    genre: 'R&B Pop'
  }
];

// Mock Users
export const users: User[] = [
  {
    id: '1',
    name: 'DJ Spinner',
    email: 'dj@example.com',
    role: 'dj',
    profileImage: 'https://images.pexels.com/photos/1699159/pexels-photo-1699159.jpeg'
  },
  {
    id: '2',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    profileImage: 'https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg'
  },
  {
    id: '3',
    name: 'Guest User',
    email: 'guest@example.com',
    role: 'guest'
  }
];

// Mock Venues
export const venues: Venue[] = [
  {
    id: '1',
    name: 'Neon Nightclub',
    logo: 'https://images.pexels.com/photos/1694900/pexels-photo-1694900.jpeg',
    theme: {
      primary: '#3B1C84',
      secondary: '#FF007F',
      accent: '#00FFFF'
    },
    address: '123 Party Street, Nightlife City',
    description: 'The hottest nightclub in town with amazing DJs and dance floors.'
  },
  {
    id: '2',
    name: 'Groove Lounge',
    logo: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg',
    theme: {
      primary: '#111827',
      secondary: '#8B5CF6',
      accent: '#EC4899'
    },
    address: '456 Chill Avenue, Downtown',
    description: 'A relaxed lounge with great music and premium drinks.'
  }
];

// Mock Requests
export const requests: Request[] = [
  {
    id: '1',
    songId: '1',
    requesterName: 'Sarah',
    venueId: '1',
    djId: '1',
    status: 'pending',
    requestTime: new Date(Date.now() - 5 * 60000).toISOString(),
    fee: 150,
    boosted: true,
    dedication: 'Happy birthday to Rachel!'
  },
  {
    id: '2',
    songId: '3',
    requesterName: 'Mike',
    venueId: '1',
    djId: '1',
    status: 'accepted',
    requestTime: new Date(Date.now() - 10 * 60000).toISOString(),
    fee: 100,
    boosted: false
  },
  {
    id: '3',
    songId: '5',
    requesterName: 'Jessica',
    venueId: '1',
    djId: '1',
    status: 'played',
    requestTime: new Date(Date.now() - 20 * 60000).toISOString(),
    fee: 100,
    boosted: false
  },
  {
    id: '4',
    songId: '7',
    requesterName: 'Tom',
    venueId: '1',
    djId: '1',
    status: 'rejected',
    requestTime: new Date(Date.now() - 15 * 60000).toISOString(),
    fee: 100,
    boosted: false
  },
  {
    id: '5',
    songId: '2',
    requesterName: 'Jamie',
    venueId: '1',
    djId: '1',
    status: 'pending',
    requestTime: new Date(Date.now() - 3 * 60000).toISOString(),
    fee: 250,
    boosted: true
  }
];