import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './contexts/AppContext';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import NowPlaying from './components/NowPlaying';
import Landing from './pages/Landing';
import SongBrowser from './pages/SongBrowser';
import SongDetail from './pages/SongDetail';
import QueueView from './pages/QueueView';
import Login from './pages/Login';
import DJDashboard from './pages/DJDashboard';
import AdminDashboard from './pages/AdminDashboard';
import AdminVenues from './pages/AdminVenues';

// Route guard for protected routes
const ProtectedRoute: React.FC<{ 
  element: React.ReactNode;
  role?: 'dj' | 'admin';
}> = ({ element, role }) => {
  // In a real app, you would check authentication status here
  
  // For demo, we'll just proceed
  return <>{element}</>;
};

function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <div className="flex flex-col min-h-screen bg-gray-800 text-white">
          <Header />
          
          <main className="flex-grow">
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Landing />} />
              <Route path="/songs" element={<SongBrowser />} />
              <Route path="/songs/:songId" element={<SongDetail />} />
              <Route path="/queue" element={<QueueView />} />
              <Route path="/login" element={<Login />} />
              
              {/* Protected Routes */}
              <Route 
                path="/dj/dashboard" 
                element={<ProtectedRoute element={<DJDashboard />} role="dj" />} 
              />
              <Route 
                path="/admin/dashboard" 
                element={<ProtectedRoute element={<AdminDashboard />} role="admin" />} 
              />
              <Route 
                path="/admin/venues" 
                element={<ProtectedRoute element={<AdminVenues />} role="admin" />} 
              />
              
              {/* Catch-all redirect */}
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
          
          <NowPlaying />
          <Footer />
        </div>
      </AppProvider>
    </BrowserRouter>
  );
}

export default App;