import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { useAppContext } from '../contexts/AppContext';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const { login } = useAppContext();
  const navigate = useNavigate();
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    try {
      const success = await login(email, password);
      
      if (success) {
        // Navigate based on role
        if (email === 'dj@example.com') {
          navigate('/dj/dashboard');
        } else if (email === 'admin@example.com') {
          navigate('/admin/dashboard');
        } else {
          navigate('/');
        }
      } else {
        setError('Invalid credentials. Please try again.');
      }
    } catch (err) {
      setError('An error occurred during login.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-md mx-auto">
        <div className="bg-gray-900 rounded-lg p-8 border border-gray-800">
          <h1 className="text-2xl font-bold text-white mb-6 text-center">
            DJRequesta Login
          </h1>
          
          <p className="text-gray-400 mb-6 text-center">
            For DJs and venue administrators only.
          </p>
          
          {error && (
            <div className="bg-red-900/50 border border-red-500 text-white px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
          
          <form onSubmit={handleLogin}>
            <Input
              label="Email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            
            <Input
              label="Password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            
            <div className="mb-4">
              <a href="#" className="text-blue-400 hover:text-blue-300 text-sm">
                Forgot your password?
              </a>
            </div>
            
            <Button
              type="submit"
              fullWidth
              disabled={isLoading}
            >
              {isLoading ? 'Logging in...' : 'Login'}
            </Button>
          </form>
          
          {/* Demo Credentials Alert */}
          <div className="mt-6 bg-gray-800 p-4 rounded-lg text-sm">
            <p className="text-white font-semibold mb-1">Demo Credentials:</p>
            <p className="text-gray-400">DJ: dj@example.com (any password)</p>
            <p className="text-gray-400">Admin: admin@example.com (any password)</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;