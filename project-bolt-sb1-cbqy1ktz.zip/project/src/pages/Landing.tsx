import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Music } from 'lucide-react';
import Button from '../components/ui/Button';
import { useAppContext } from '../contexts/AppContext';

const Landing: React.FC = () => {
  const navigate = useNavigate();
  const { nowPlaying, currentVenue } = useAppContext();

  return (
    <div className="min-h-[calc(100vh-10rem)] flex flex-col">
      {/* Hero Section */}
      <div 
        className="relative py-16 px-4 md:py-24 flex-grow"
        style={{
          background: 'linear-gradient(rgba(17, 24, 39, 0.8), rgba(17, 24, 39, 0.9)), url(https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto text-center z-10 relative">
          <div className="inline-block p-3 rounded-full bg-purple-900/50 mb-6">
            <Music size={40} className="text-fuchsia-500" />
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            DJRequesta
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Request your favorite songs at {currentVenue?.name || 'this venue'}. Pay to prioritize your requests and make the night yours!
          </p>
          
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => navigate('/songs')}
            >
              Request a Song
            </Button>
            
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => navigate('/queue')}
            >
              View Request Queue
            </Button>
          </div>
          
          {nowPlaying && (
            <div className="mt-14 bg-gray-900/70 rounded-lg p-6 max-w-md mx-auto">
              <h2 className="text-xl font-semibold text-white mb-2">
                Currently Playing
              </h2>
              
              <div className="flex items-center">
                <img 
                  src={nowPlaying.coverImage} 
                  alt={nowPlaying.title} 
                  className="w-16 h-16 rounded-md object-cover"
                />
                
                <div className="ml-4 text-left">
                  <p className="font-bold text-white">{nowPlaying.title}</p>
                  <p className="text-gray-400">{nowPlaying.artist}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* How It Works Section */}
      <div className="bg-gray-900 py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            How It Works
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">1</span>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Browse Songs
              </h3>
              <p className="text-gray-400">
                Browse our catalog or search for your favorite track to request.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">2</span>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Make Payment
              </h3>
              <p className="text-gray-400">
                Pay a small fee to submit your request. Boost to prioritize it.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-fuchsia-600 flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-lg">3</span>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Enjoy Your Song
              </h3>
              <p className="text-gray-400">
                Wait for the DJ to play your song and enjoy the moment!
              </p>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Button 
              size="lg" 
              onClick={() => navigate('/songs')}
            >
              Request Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Landing;