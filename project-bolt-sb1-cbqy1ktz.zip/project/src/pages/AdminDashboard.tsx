import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import { useAppContext } from '../contexts/AppContext';

const AdminDashboard: React.FC = () => {
  const { currentUser, songRequests, venues } = useAppContext();
  const navigate = useNavigate();
  
  // Redirect if not an admin
  if (currentUser?.role !== 'admin') {
    navigate('/login');
    return null;
  }
  
  // Calculate some basic stats
  const stats = useMemo(() => {
    const totalRequests = songRequests.length;
    const totalRevenue = songRequests.reduce((acc, req) => acc + req.fee, 0);
    const completedRequests = songRequests.filter(req => req.status === 'played').length;
    
    const requestsByVenue = venues.map(venue => {
      const venueRequests = songRequests.filter(req => req.venueId === venue.id);
      return {
        venueId: venue.id,
        venueName: venue.name,
        count: venueRequests.length,
        revenue: venueRequests.reduce((acc, req) => acc + req.fee, 0)
      };
    });
    
    return {
      totalRequests,
      totalRevenue,
      completedRequests,
      requestsByVenue
    };
  }, [songRequests, venues]);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
            Admin Dashboard
          </h1>
          <p className="text-gray-400">
            Welcome back, {currentUser.name}
          </p>
        </div>
        
        <div className="mt-4 md:mt-0">
          <Button onClick={() => navigate('/admin/venues')}>
            Manage Venues
          </Button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <p className="text-gray-400 text-sm mb-1">Total Requests</p>
          <p className="text-3xl font-bold text-white">{stats.totalRequests}</p>
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <p className="text-gray-400 text-sm mb-1">Completed Requests</p>
          <p className="text-3xl font-bold text-white">{stats.completedRequests}</p>
        </div>
        
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
          <p className="text-gray-400 text-sm mb-1">Total Revenue</p>
          <p className="text-3xl font-bold text-green-400">₹{stats.totalRevenue}</p>
        </div>
      </div>
      
      {/* Venue Performance */}
      <div className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden mb-8">
        <div className="p-4 border-b border-gray-800">
          <h2 className="text-xl font-semibold text-white">Venue Performance</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-800">
              <tr>
                <th className="p-4 text-gray-400 font-semibold">Venue</th>
                <th className="p-4 text-gray-400 font-semibold">Requests</th>
                <th className="p-4 text-gray-400 font-semibold">Revenue</th>
                <th className="p-4 text-gray-400 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {stats.requestsByVenue.map((venue) => (
                <tr key={venue.venueId} className="border-t border-gray-800">
                  <td className="p-4 text-white font-medium">{venue.venueName}</td>
                  <td className="p-4 text-gray-300">{venue.count}</td>
                  <td className="p-4 text-green-400">₹{venue.revenue}</td>
                  <td className="p-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {}}
                    >
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="bg-gray-900 border border-gray-800 rounded-lg p-6">
        <h2 className="text-xl font-semibold text-white mb-4">Quick Actions</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            variant="secondary"
            onClick={() => {}}
          >
            Add New Venue
          </Button>
          
          <Button
            variant="secondary"
            onClick={() => {}}
          >
            Manage DJs
          </Button>
          
          <Button
            variant="secondary"
            onClick={() => {}}
          >
            Export Reports
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;