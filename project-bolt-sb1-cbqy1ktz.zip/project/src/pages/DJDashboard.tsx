import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import RequestCard from '../components/ui/RequestCard';
import { useAppContext } from '../contexts/AppContext';

const DJDashboard: React.FC = () => {
  const { currentUser, songRequests, allSongs } = useAppContext();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'pending' | 'accepted' | 'completed'>('pending');
  
  // Redirect if not a DJ
  if (currentUser?.role !== 'dj') {
    navigate('/login');
    return null;
  }
  
  // Filter requests based on active tab
  const filteredRequests = useMemo(() => {
    switch (activeTab) {
      case 'pending':
        return songRequests.filter(req => req.status === 'pending');
      case 'accepted':
        return songRequests.filter(req => req.status === 'accepted');
      case 'completed':
        return songRequests.filter(req => req.status === 'played' || req.status === 'rejected');
      default:
        return [];
    }
  }, [songRequests, activeTab]);
  
  // Calculate earnings
  const totalEarnings = useMemo(() => {
    return songRequests
      .filter(req => req.status === 'played' || req.status === 'accepted')
      .reduce((total, req) => total + req.fee, 0);
  }, [songRequests]);
  
  // Get song objects for each request
  const requestsWithSongs = useMemo(() => {
    return filteredRequests.map(request => {
      const song = allSongs.find(s => s.id === request.songId);
      return { request, song: song! };
    }).filter(({ song }) => song !== undefined);
  }, [filteredRequests, allSongs]);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
            DJ Dashboard
          </h1>
          <p className="text-gray-400">
            Welcome back, {currentUser.name}
          </p>
        </div>
        
        <div className="mt-4 md:mt-0 bg-gray-900 p-4 rounded-lg border border-green-500">
          <p className="text-sm text-gray-400">Total Earnings</p>
          <p className="text-2xl font-bold text-green-400">₹{totalEarnings}</p>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-800 mb-6">
        <div className="flex overflow-x-auto">
          <button
            className={`py-2 px-4 font-medium text-sm mr-4 border-b-2 ${
              activeTab === 'pending' 
                ? 'border-fuchsia-500 text-white' 
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('pending')}
          >
            Pending Requests
          </button>
          
          <button
            className={`py-2 px-4 font-medium text-sm mr-4 border-b-2 ${
              activeTab === 'accepted' 
                ? 'border-fuchsia-500 text-white' 
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('accepted')}
          >
            Accepted
          </button>
          
          <button
            className={`py-2 px-4 font-medium text-sm mr-4 border-b-2 ${
              activeTab === 'completed' 
                ? 'border-fuchsia-500 text-white' 
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            onClick={() => setActiveTab('completed')}
          >
            Completed
          </button>
        </div>
      </div>
      
      {/* Request Cards */}
      {requestsWithSongs.length === 0 ? (
        <div className="text-center py-12 bg-gray-900 rounded-lg">
          <p className="text-gray-400">
            No {activeTab} requests at the moment.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {requestsWithSongs.map(({ request, song }) => (
            <RequestCard
              key={request.id}
              request={request}
              song={song}
              isDj={true}
            />
          ))}
        </div>
      )}
      
      {/* Quick Navigation */}
      <div className="mt-8 flex flex-wrap gap-4">
        <Button
          variant="outline"
          onClick={() => navigate('/queue')}
        >
          View Queue
        </Button>
        
        <Button
          variant="secondary"
          onClick={() => navigate('/songs')}
        >
          View Song Library
        </Button>
      </div>
    </div>
  );
};

export default DJDashboard;