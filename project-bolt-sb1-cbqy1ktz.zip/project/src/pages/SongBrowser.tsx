import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import SongCard from '../components/ui/SongCard';
import Input from '../components/ui/Input';
import { useAppContext } from '../contexts/AppContext';

const SongBrowser: React.FC = () => {
  const { filteredSongs, searchSongs, songRequests } = useAppContext();
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    searchSongs(query);
  };

  const isRequested = (songId: string) => {
    return songRequests.some(
      request => request.songId === songId && 
      (request.status === 'pending' || request.status === 'accepted')
    );
  };

  const handleRequestSong = (songId: string) => {
    navigate(`/songs/${songId}`);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl md:text-3xl font-bold text-white mb-6">
        Request a Song
      </h1>
      
      <div className="mb-8">
        <Input
          type="text"
          placeholder="Search for songs, artists or albums..."
          value={searchQuery}
          onChange={handleSearch}
          icon={<Search className="w-5 h-5 text-gray-400" />}
        />
      </div>
      
      {filteredSongs.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-400 text-lg">
            No songs found matching "{searchQuery}". Try a different search.
          </p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredSongs.map(song => (
              <SongCard
                key={song.id}
                song={song}
                isRequested={isRequested(song.id)}
                onRequest={() => handleRequestSong(song.id)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default SongBrowser;