import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, MessageCircle } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useAppContext } from '../contexts/AppContext';

const SongDetail: React.FC = () => {
  const { songId } = useParams<{ songId: string }>();
  const navigate = useNavigate();
  const { allSongs, addRequest, currentVenue } = useAppContext();
  
  const song = allSongs.find(s => s.id === songId);
  
  const [requesterName, setRequesterName] = useState('');
  const [dedication, setDedication] = useState('');
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  
  if (!song) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <p className="text-red-500 text-lg">Song not found</p>
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => navigate('/songs')}
        >
          Back to Songs
        </Button>
      </div>
    );
  }
  
  const handleSubmitRequest = () => {
    if (!requesterName.trim()) {
      alert('Please enter your name');
      return;
    }
    setShowPaymentForm(true);
  };
  
  const handlePayment = () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      // Add request to the queue
      addRequest({
        songId: song.id,
        requesterName: requesterName,
        venueId: currentVenue?.id || '1',
        status: 'pending',
        fee: 100,
        boosted: false,
        dedication: dedication.trim() || undefined,
        paymentId: 'pay_' + Math.random().toString(36).substr(2, 9)
      });
      
      setIsProcessing(false);
      setPaymentSuccess(true);
      
      // Redirect to queue after a delay
      setTimeout(() => {
        navigate('/queue');
      }, 3000);
    }, 2000);
  };
  
  if (paymentSuccess) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-md">
        <div className="bg-gray-900 rounded-lg p-8 text-center border border-green-500">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Request Successful!</h2>
          <p className="text-gray-400 mb-6">
            Your song request has been submitted and is now in the queue.
          </p>
          <Button
            onClick={() => navigate('/queue')}
          >
            View Queue
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center text-gray-400 hover:text-white mb-6"
      >
        <ArrowLeft className="mr-2" size={16} />
        Back to Songs
      </button>
      
      <div className="max-w-4xl mx-auto">
        <div className="bg-gray-900 rounded-lg overflow-hidden border border-gray-800">
          <div className="md:flex">
            <div className="md:w-1/3">
              <img
                src={song.coverImage}
                alt={song.title}
                className="w-full h-64 md:h-full object-cover"
              />
            </div>
            
            <div className="p-6 md:p-8 md:w-2/3">
              <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
                {song.title}
              </h1>
              
              <p className="text-xl text-gray-400 mb-4">
                {song.artist}
              </p>
              
              {song.album && (
                <p className="text-gray-500 mb-2">
                  Album: {song.album}
                </p>
              )}
              
              {song.genre && (
                <p className="text-gray-500 mb-4">
                  Genre: {song.genre}
                </p>
              )}
              
              <div className="mt-6 mb-6 p-4 bg-gradient-to-r from-blue-900/50 to-purple-900/50 rounded-lg">
                <h3 className="text-white font-semibold mb-2">Request Fee</h3>
                <p className="text-2xl font-bold text-green-400">₹100</p>
                <p className="text-sm text-gray-400 mt-1">
                  Pay to prioritize your request in the DJ's queue.
                </p>
              </div>
              
              {!showPaymentForm ? (
                <div>
                  <Input
                    label="Your Name"
                    placeholder="Enter your name"
                    value={requesterName}
                    onChange={(e) => setRequesterName(e.target.value)}
                    required
                  />
                  
                  <Input
                    label="Add a Dedication (Optional)"
                    placeholder="e.g., Happy Birthday to Sarah!"
                    value={dedication}
                    onChange={(e) => setDedication(e.target.value)}
                    icon={<MessageCircle className="w-5 h-5 text-gray-400" />}
                  />
                  
                  <Button
                    className="mt-4"
                    fullWidth
                    onClick={handleSubmitRequest}
                    disabled={!requesterName.trim()}
                  >
                    Continue to Payment
                  </Button>
                </div>
              ) : (
                <div className="bg-gray-800 p-4 rounded-lg">
                  <h3 className="text-white text-lg font-semibold mb-4">
                    Payment Details
                  </h3>
                  
                  <div className="mb-4">
                    <Input
                      label="Card Number"
                      placeholder="1234 5678 9012 3456"
                      icon={<CreditCard className="w-5 h-5 text-gray-400" />}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <Input
                      label="Expiry Date"
                      placeholder="MM/YY"
                    />
                    <Input
                      label="CVC"
                      placeholder="123"
                    />
                  </div>
                  
                  <Button
                    fullWidth
                    onClick={handlePayment}
                    disabled={isProcessing}
                  >
                    {isProcessing ? 'Processing...' : 'Pay ₹100'}
                  </Button>
                  
                  <p className="text-gray-500 text-sm text-center mt-4">
                    You're authorizing a payment of ₹100 for this song request.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SongDetail;