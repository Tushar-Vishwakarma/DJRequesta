import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/ui/Button';
import { useAppContext } from '../contexts/AppContext';

const AdminVenues: React.FC = () => {
  const { currentUser, venues } = useAppContext();
  const navigate = useNavigate();
  
  // Redirect if not an admin
  if (currentUser?.role !== 'admin') {
    navigate('/login');
    return null;
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-white">
          Manage Venues
        </h1>
        
        <div className="mt-4 md:mt-0">
          <Button onClick={() => {}}>
            Add New Venue
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {venues.map((venue) => (
          <div 
            key={venue.id}
            className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden"
          >
            <div className="h-48 overflow-hidden relative">
              <div 
                className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent z-10"
              ></div>
              <img 
                src={venue.logo || 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg'} 
                alt={venue.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 p-4 z-20">
                <h2 className="text-2xl font-bold text-white">{venue.name}</h2>
              </div>
            </div>
            
            <div className="p-4">
              <p className="text-gray-400 mb-4">{venue.description}</p>
              
              <div className="mb-4">
                <p className="text-gray-500 text-sm">Address</p>
                <p className="text-white">{venue.address}</p>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {}}
                >
                  Edit Details
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {}}
                >
                  Manage DJs
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {}}
                >
                  View Analytics
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminVenues;