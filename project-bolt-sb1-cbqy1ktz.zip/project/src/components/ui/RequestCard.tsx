import React from 'react';
import { Request } from '../../types';
import { Song } from '../../types';
import Button from './Button';
import { useAppContext } from '../../contexts/AppContext';

interface RequestCardProps {
  request: Request;
  song: Song;
  isDj?: boolean;
}

const RequestCard: React.FC<RequestCardProps> = ({ request, song, isDj = false }) => {
  const { updateRequestStatus, boostedRequest } = useAppContext();

  const getStatusBadge = () => {
    switch (request.status) {
      case 'pending':
        return <span className="bg-yellow-500 text-yellow-900 px-2 py-1 rounded-full text-xs font-semibold">Pending</span>;
      case 'accepted':
        return <span className="bg-green-500 text-green-900 px-2 py-1 rounded-full text-xs font-semibold">Accepted</span>;
      case 'rejected':
        return <span className="bg-red-500 text-red-900 px-2 py-1 rounded-full text-xs font-semibold">Rejected</span>;
      case 'played':
        return <span className="bg-blue-500 text-blue-900 px-2 py-1 rounded-full text-xs font-semibold">Played</span>;
      default:
        return null;
    }
  };

  const formatTime = (timeString: string) => {
    const date = new Date(timeString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleAccept = () => {
    updateRequestStatus(request.id, 'accepted');
  };

  const handleReject = () => {
    updateRequestStatus(request.id, 'rejected');
  };

  const handlePlayed = () => {
    updateRequestStatus(request.id, 'played');
  };

  const handleBoost = () => {
    boostedRequest(request.id);
  };

  return (
    <div className={`
      border border-gray-800 rounded-lg overflow-hidden
      ${request.boosted ? 'bg-gradient-to-r from-blue-900/50 to-purple-900/50 shadow-md shadow-purple-500/20' : 'bg-gray-900'}
      transition-all duration-300 hover:border-gray-700
    `}>
      <div className="flex items-start p-4">
        <div className="flex-shrink-0 mr-4">
          <img 
            src={song.coverImage} 
            alt={song.title} 
            className="w-16 h-16 rounded-md object-cover" 
          />
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between">
            <div>
              <h3 className="font-bold text-white">{song.title}</h3>
              <p className="text-sm text-gray-400">{song.artist}</p>
            </div>
            <div className="text-right">
              {getStatusBadge()}
              <p className="text-xs text-gray-500 mt-1">
                {formatTime(request.requestTime)}
              </p>
            </div>
          </div>
          
          <div className="mt-2 flex flex-wrap items-center">
            <span className="text-sm text-gray-400 mr-3">
              From: {request.requesterName}
            </span>
            <span className="text-sm font-semibold text-green-400">
              ₹{request.fee}
            </span>
            
            {request.dedication && (
              <div className="w-full mt-1">
                <p className="text-xs italic text-gray-400">
                  "{request.dedication}"
                </p>
              </div>
            )}
          </div>
          
          {isDj && request.status === 'pending' && (
            <div className="mt-3 flex space-x-2">
              <Button 
                variant="success" 
                size="sm" 
                onClick={handleAccept}
              >
                Accept
              </Button>
              <Button 
                variant="danger" 
                size="sm" 
                onClick={handleReject}
              >
                Reject
              </Button>
            </div>
          )}
          
          {isDj && request.status === 'accepted' && (
            <div className="mt-3">
              <Button 
                variant="primary" 
                size="sm" 
                onClick={handlePlayed}
              >
                Mark as Played
              </Button>
            </div>
          )}
          
          {!isDj && request.status === 'pending' && !request.boosted && (
            <div className="mt-3">
              <Button 
                variant="secondary" 
                size="sm" 
                onClick={handleBoost}
              >
                Boost Request (+₹100)
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RequestCard;