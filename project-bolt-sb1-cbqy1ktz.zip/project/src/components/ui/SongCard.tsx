import React from 'react';
import { Song } from '../../types';
import Button from './Button';

interface SongCardProps {
  song: Song;
  onRequest?: () => void;
  showRequestButton?: boolean;
  isPlaying?: boolean;
  isRequested?: boolean;
}

const SongCard: React.FC<SongCardProps> = ({
  song,
  onRequest,
  showRequestButton = true,
  isPlaying = false,
  isRequested = false
}) => {
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div 
      className={`
        relative rounded-lg overflow-hidden bg-gray-900 border border-gray-800
        hover:border-purple-500 transition-all duration-300
        ${isPlaying ? 'border-2 border-fuchsia-500 shadow-lg shadow-fuchsia-500/30' : ''}
        ${isRequested ? 'border-2 border-blue-500' : ''}
      `}
    >
      <div className="relative">
        <img 
          src={song.coverImage} 
          alt={`${song.title} by ${song.artist}`}
          className="w-full h-48 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-70"></div>
        
        {isPlaying && (
          <div className="absolute top-2 right-2 bg-fuchsia-500 text-white px-2 py-1 rounded-full text-xs font-bold">
            NOW PLAYING
          </div>
        )}
        
        {isRequested && (
          <div className="absolute top-2 right-2 bg-blue-500 text-white px-2 py-1 rounded-full text-xs font-bold">
            REQUESTED
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-bold text-white truncate">{song.title}</h3>
        <p className="text-gray-400">{song.artist}</p>
        <div className="flex justify-between items-center mt-3">
          <span className="text-gray-500 text-sm">{formatDuration(song.duration)}</span>
          {song.genre && (
            <span className="bg-gray-800 text-gray-300 text-xs px-2 py-1 rounded">
              {song.genre}
            </span>
          )}
        </div>
        
        {showRequestButton && !isPlaying && !isRequested && (
          <div className="mt-4">
            <Button
              variant="primary"
              fullWidth
              onClick={onRequest}
            >
              Request Song ₹100
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SongCard;