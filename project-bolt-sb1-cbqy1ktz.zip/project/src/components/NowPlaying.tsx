import React from 'react';
import { useAppContext } from '../contexts/AppContext';

const NowPlaying: React.FC = () => {
  const { nowPlaying } = useAppContext();

  if (!nowPlaying) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-blue-900 to-purple-900 border-t border-gray-800 py-2 px-4 z-10">
      <div className="container mx-auto flex items-center">
        <div className="flex-shrink-0 mr-3">
          <img 
            src={nowPlaying.coverImage} 
            alt={nowPlaying.title} 
            className="w-12 h-12 rounded-md object-cover"
          />
        </div>
        
        <div className="flex-1">
          <p className="text-white font-bold">Now Playing</p>
          <div className="flex items-center">
            <p className="text-white">{nowPlaying.title}</p>
            <span className="mx-2 text-gray-400">•</span>
            <p className="text-gray-400">{nowPlaying.artist}</p>
          </div>
        </div>

        {/* Animated equalizer bars */}
        <div className="hidden md:flex items-end h-8 space-x-1">
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className="w-1 bg-fuchsia-400 rounded-t-sm"
              style={{
                height: `${Math.floor(Math.random() * 100)}%`,
                animation: `equalizer ${Math.random() * 0.8 + 0.5}s ease-in-out infinite alternate`,
              }}
            ></div>
          ))}
        </div>
      </div>

      {/* CSS Animation */}
      <style jsx>{`
        @keyframes equalizer {
          0% {
            height: 10%;
          }
          100% {
            height: 100%;
          }
        }
      `}</style>
    </div>
  );
};

export default NowPlaying;